/**
 * 
 */
$(document).ready(function(){
	
	$('#login_btn').click(function(){
		var flag = false;
		var id = $('#id').val();
		var pwd = $('#pwd').val();
		alert(id+":"+pwd);
		//Ajax연결해서 
		$.ajax({
			data :  {id : id, pwd : pwd },
			type : "post",
			dataType: "text",
			async: false,
			url : '/login/login_check',
			success : function(data, textStatus){
				//성공여부를 출력합니다.
				//alert(data);
				if(eval(data)==true){
					alert(id+"님 login ok Status Success");
					flag = true;
					window.location.href = '/login/success';
				} else{
					alert("ID or PWD is wrong");
				}
				
			},
			error : function(data, textStatus){
				$('#message').text('error');
			},
			complete : function(data,textStatus){
				//alert(flag);
				//alert('complete '+flag);
			}
		});		
		return flag;
	})
});
