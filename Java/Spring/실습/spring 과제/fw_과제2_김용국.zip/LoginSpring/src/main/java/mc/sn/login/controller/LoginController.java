package mc.sn.login.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import mc.sn.login.service.LoginService;
import mc.sn.login.vo.MemberVO;




/**
 * Servlet implementation class LoginController
 */
@Controller("loginController")
public class LoginController{
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	@Autowired
	private LoginService loginService;
	@Autowired
	private MemberVO memberVO ;
	
	@ResponseBody
	@RequestMapping(value="/login_check",method = RequestMethod.POST)
	public void check(@RequestParam Map<String,String> info,HttpServletRequest request, HttpServletResponse response) throws Exception {
		String id = info.get("id");
		String pwd = info.get("pwd");
		boolean flag = loginService.checkLogin(id, pwd);
		response.getWriter().print(flag);
	}
	@RequestMapping(value="/success",method = RequestMethod.GET)
	public ModelAndView result(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String url = "result";
		ModelAndView mav = new ModelAndView();
		mav.setViewName(url);
		mav.addObject("message","success");	
		return mav;
	}
	
	@RequestMapping(value="/login_form" ,method = RequestMethod.GET)
	public ModelAndView form(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String url = "test";
		ModelAndView mav = new ModelAndView();
		mav.setViewName(url);
		return mav;
	}

}
