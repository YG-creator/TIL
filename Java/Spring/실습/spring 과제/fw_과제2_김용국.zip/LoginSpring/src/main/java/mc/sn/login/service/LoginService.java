package mc.sn.login.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import mc.sn.login.dao.LoginDAO;

@Service("loginService")
public class LoginService {
	
	@Autowired
	private LoginDAO loginDAO;
	//湲곕낯 CRUD �옉�뾽�뿉�꽌 踰쀬뼱�궃 �옉�뾽
	
	public boolean checkLogin(String id, String pwd) throws DataAccessException {
		boolean flag = false; //�빐�떦 user媛� �뾾�떎.
		flag = loginDAO.selectUser(id, pwd);
		return flag;
	}
}
