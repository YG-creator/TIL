/**
 * 
 */
$(document).ready(function(){
	$('#login_btn').click(function(){
		var id = $('#id').val();
		var pwd = $('#pwd').val();
		alert(id+":"+pwd);
	});
});


