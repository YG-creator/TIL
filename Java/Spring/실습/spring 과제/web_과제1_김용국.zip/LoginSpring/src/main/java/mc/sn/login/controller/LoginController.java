package mc.sn.login.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import mc.sn.login.service.LoginService;
import mc.sn.login.vo.MemberVO;




/**
 * Servlet implementation class LoginController
 */
@Controller("loginController")
public class LoginController{
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	@Autowired
	private LoginService loginService;
	@Autowired
	private MemberVO memberVO ;
	
	/*
	 * @RequestMapping(value="/login_check",method = RequestMethod.POST) public
	 * ModelAndView login(@RequestParam Map<String,String> info,HttpServletRequest
	 * request, HttpServletResponse response) throws Exception { String id =
	 * info.get("id"); String pwd = info.get("pwd"); ModelAndView mav = new
	 * ModelAndView(); String url = "result"; boolean flag =
	 * loginService.checkLogin(id, pwd); String message = ""; if(flag) { message =
	 * id+"님 login ok Status Success"; mav.addObject("message",message); } else {
	 * message = "fail"; mav.addObject("message",message); } mav.setViewName(url);
	 * return mav; }
	 */
	
	@RequestMapping(value="/login_form" ,method = RequestMethod.GET)
	public ModelAndView form(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String url = "test";
		ModelAndView mav = new ModelAndView(url);
		return mav;
	}

}
